package com.opl.common.agristack;

public class DataOnSeek {
	public String reg_record_type;
	public RegRecords reg_records;

	public String getReg_record_type() {
		return reg_record_type;
	}

	public void setReg_record_type(String reg_record_type) {
		this.reg_record_type = reg_record_type;
	}

	public RegRecords getReg_records() {
		return reg_records;
	}

	public void setReg_records(RegRecords reg_records) {
		this.reg_records = reg_records;
	}

}
