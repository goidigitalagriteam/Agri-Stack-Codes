package com.opl.common.agristack;

import java.util.List;

public class Message {

	public String transaction_id;
	public String correlation_id;
	public List<SearchResponse> search_response;
	public Pagination pagination;
	public String locale;

	public String getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}

	public String getCorrelation_id() {
		return correlation_id;
	}

	public void setCorrelation_id(String correlation_id) {
		this.correlation_id = correlation_id;
	}

	public List<SearchResponse> getSearch_response() {
		return search_response;
	}

	public void setSearch_response(List<SearchResponse> search_response) {
		this.search_response = search_response;
	}

	public Pagination getPagination() {
		return pagination;
	}

	public void setPagination(Pagination pagination) {
		this.pagination = pagination;
	}

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

}
