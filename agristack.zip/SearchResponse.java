package com.opl.common.agristack;

public class SearchResponse {

	public String reference_id;
	public DataOnSeek data;

	public DataOnSeek getData() {
		return data;
	}

	public void setData(DataOnSeek data) {
		this.data = data;
	}

	public String getReference_id() {
		return reference_id;
	}

	public void setReference_id(String reference_id) {
		this.reference_id = reference_id;
	}

}
