package com.opl.common.agristack;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;

@RequestMapping("/aiu")
@RestController()
public class AgriStackPublishController {


	private static final Logger logger = LoggerFactory.getLogger(AgriStackPublishController.class);


	@PostMapping(value = "/on-seek", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> onSeek(@RequestBody OnSeekRequestProxy request) throws Exception {

		logger.info("Enter in get onSeek Details ----------------->" );
		try {
			/**
			 *Service layer logic put here  
			 */
			
			logger.info("onSeek Request Details ----------------->" + getStringfromObject(request));
			
			return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully Recived Request!!", request, HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception", e);
			return new ResponseEntity<CommonResponse>(new CommonResponse("Something went wrong while getStatus :-" + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}
	
	public static String getStringfromObject(Object object) throws Exception {
		if (object != null) {
			return new ObjectMapper().writeValueAsString(object);
		} else {
			return "{}";
		}
	}

}
