package com.opl.common.agristack;

public class OwnerDetail {

	public String khata_number;
	public String owner_number;
	public String main_owner_number;
	public String owner_name;
	public String owner_extent;
	public String owner_extent_decimal_part;
	public String owner_share;
	public String land_usage_type;
	public String owner_category;
	public String identifier_type;
	public String identifier_name;
	public String government_liability;
	public String public_liability;

	public String getKhata_number() {
		return khata_number;
	}

	public void setKhata_number(String khata_number) {
		this.khata_number = khata_number;
	}

	public String getOwner_number() {
		return owner_number;
	}

	public void setOwner_number(String owner_number) {
		this.owner_number = owner_number;
	}

	public String getMain_owner_number() {
		return main_owner_number;
	}

	public void setMain_owner_number(String main_owner_number) {
		this.main_owner_number = main_owner_number;
	}

	public String getOwner_name() {
		return owner_name;
	}

	public void setOwner_name(String owner_name) {
		this.owner_name = owner_name;
	}

	public String getOwner_extent() {
		return owner_extent;
	}

	public void setOwner_extent(String owner_extent) {
		this.owner_extent = owner_extent;
	}

	public String getOwner_extent_decimal_part() {
		return owner_extent_decimal_part;
	}

	public void setOwner_extent_decimal_part(String owner_extent_decimal_part) {
		this.owner_extent_decimal_part = owner_extent_decimal_part;
	}

	public String getOwner_share() {
		return owner_share;
	}

	public void setOwner_share(String owner_share) {
		this.owner_share = owner_share;
	}

	public String getLand_usage_type() {
		return land_usage_type;
	}

	public void setLand_usage_type(String land_usage_type) {
		this.land_usage_type = land_usage_type;
	}

	public String getOwner_category() {
		return owner_category;
	}

	public void setOwner_category(String owner_category) {
		this.owner_category = owner_category;
	}

	public String getIdentifier_type() {
		return identifier_type;
	}

	public void setIdentifier_type(String identifier_type) {
		this.identifier_type = identifier_type;
	}

	public String getIdentifier_name() {
		return identifier_name;
	}

	public void setIdentifier_name(String identifier_name) {
		this.identifier_name = identifier_name;
	}

	public String getGovernment_liability() {
		return government_liability;
	}

	public void setGovernment_liability(String government_liability) {
		this.government_liability = government_liability;
	}

	public String getPublic_liability() {
		return public_liability;
	}

	public void setPublic_liability(String public_liability) {
		this.public_liability = public_liability;
	}

}
