package com.opl.common.agristack;

import java.util.List;

public class RegRecords {
	public String village_lgd_code;
	public LandIdentifiers land_identifiers;
	public String total_plot_area;
	public String total_plot_area_decimal_part;
	public String area_unit;
	public List<OwnerDetail> owner_details;

	public String getVillage_lgd_code() {
		return village_lgd_code;
	}

	public void setVillage_lgd_code(String village_lgd_code) {
		this.village_lgd_code = village_lgd_code;
	}

	public LandIdentifiers getLand_identifiers() {
		return land_identifiers;
	}

	public void setLand_identifiers(LandIdentifiers land_identifiers) {
		this.land_identifiers = land_identifiers;
	}

	public String getTotal_plot_area() {
		return total_plot_area;
	}

	public void setTotal_plot_area(String total_plot_area) {
		this.total_plot_area = total_plot_area;
	}

	public String getTotal_plot_area_decimal_part() {
		return total_plot_area_decimal_part;
	}

	public void setTotal_plot_area_decimal_part(String total_plot_area_decimal_part) {
		this.total_plot_area_decimal_part = total_plot_area_decimal_part;
	}

	public String getArea_unit() {
		return area_unit;
	}

	public void setArea_unit(String area_unit) {
		this.area_unit = area_unit;
	}

	public List<OwnerDetail> getOwner_details() {
		return owner_details;
	}

	public void setOwner_details(List<OwnerDetail> owner_details) {
		this.owner_details = owner_details;
	}

}
