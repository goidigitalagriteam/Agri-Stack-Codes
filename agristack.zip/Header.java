package com.opl.common.agristack;

import java.util.Date;

public class Header {

	public String version;
	public String message_id;
	public Date message_ts;
	public String action;
	public String status;
	public String status_reason_code;
	public String status_reason_message;
	public Integer total_count;
	public Integer completed_count;
	public String sender_id;
	public String receiver_id;
	public Boolean is_msg_encrypted;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getMessage_id() {
		return message_id;
	}

	public void setMessage_id(String message_id) {
		this.message_id = message_id;
	}

	public Date getMessage_ts() {
		return message_ts;
	}

	public void setMessage_ts(Date message_ts) {
		this.message_ts = message_ts;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus_reason_code() {
		return status_reason_code;
	}

	public void setStatus_reason_code(String status_reason_code) {
		this.status_reason_code = status_reason_code;
	}

	public String getStatus_reason_message() {
		return status_reason_message;
	}

	public void setStatus_reason_message(String status_reason_message) {
		this.status_reason_message = status_reason_message;
	}

	public Integer getTotal_count() {
		return total_count;
	}

	public void setTotal_count(Integer total_count) {
		this.total_count = total_count;
	}

	public Integer getCompleted_count() {
		return completed_count;
	}

	public void setCompleted_count(Integer completed_count) {
		this.completed_count = completed_count;
	}

	public String getSender_id() {
		return sender_id;
	}

	public void setSender_id(String sender_id) {
		this.sender_id = sender_id;
	}

	public String getReceiver_id() {
		return receiver_id;
	}

	public void setReceiver_id(String receiver_id) {
		this.receiver_id = receiver_id;
	}

	public Boolean getIs_msg_encrypted() {
		return is_msg_encrypted;
	}

	public void setIs_msg_encrypted(Boolean is_msg_encrypted) {
		this.is_msg_encrypted = is_msg_encrypted;
	}

}
