package com.opl.common.agristack;

public class LandIdentifiers {

	public String survey_number;
	public String unique_land_code;

	public String getSurvey_number() {
		return survey_number;
	}

	public void setSurvey_number(String survey_number) {
		this.survey_number = survey_number;
	}

	public String getUnique_land_code() {
		return unique_land_code;
	}

	public void setUnique_land_code(String unique_land_code) {
		this.unique_land_code = unique_land_code;
	}

}
